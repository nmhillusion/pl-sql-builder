select id 
from t_demo_1752
where id > (
  select count_number
  from t_number
  where id = 'FR56'
)