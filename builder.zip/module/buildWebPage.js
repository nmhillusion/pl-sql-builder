const fs = require("fs");
const nodeScss = require("node-sass");

function buildPathFromRelativePath(fileRelativePath, dir = ".") {
  return fileRelativePath.replace(/^\./, dir);
}

function buildScss(content, dir = ".") {
  const contentAfterRender = content.replace(
    /--\[\[include\(['"](.+?)["']\)\]\]/gi,
    (match, grp) => {
      let pathScssFile = buildPathFromRelativePath(grp, dir);
      if (
        String(pathScssFile).endsWith(".scss") ||
        String(pathScssFile).endsWith(".css")
      ) {
        const contentRender = nodeScss.renderSync({
          file: pathScssFile,
          outputStyle: "compressed"
        });
        return `<style>${contentRender.css.toString()}</style>`;
      } else {
        return match;
      }
    }
  );

  return contentAfterRender;
}

function buildJavascript(content, dir = ".") {
  const contentAfterRender = content.replace(
    /--\[\[include\(['"](.+?)["']\)\]\]/gi,
    (match, grp) => {
      const fileJsPath = buildPathFromRelativePath(grp, dir);
      if (String(fileJsPath).endsWith(".js")) {
        const contentRender = fs.readFileSync(fileJsPath);
        return `<script>${contentRender}</script>`;
      } else {
        return match;
      }
    }
  );
  return contentAfterRender;
}

function builder(...buildFns) {
  return (content, dir) =>
    buildFns.reduce(
      (compositeContent, fn) => fn(compositeContent, dir),
      content
    );
}

function build(dir = ".", outputFile = "--") {
  try {
    const pathWebFile = buildPathFromRelativePath("./index.html", dir);
    const contentFile = fs.readFileSync(pathWebFile).toString();
    let contentFileAfterRender = builder(buildJavascript, buildScss)(
      contentFile,
      dir
    );
    if ("--" === outputFile) {
      outputFile =
        pathWebFile.substring(0, pathWebFile.lastIndexOf(".")) +
        ".compiled" +
        pathWebFile.substring(pathWebFile.lastIndexOf("."));
    }
    fs.writeFileSync(outputFile, contentFileAfterRender);
  } catch (error) {
    console.log("Error in buildWebPage: ", error);
  }
}

module.exports = build;
