const fsp = require("./fsPromise");
const fs = require("fs");
const findAllIndexString = require("./findAllIndexString");
const countIndentSpace = require("./countIndentSpace");

async function build(pathname, dirname = ".") {
  let contentFile = "";
  try {
    contentFile = await fsp.readFile(pathname);
    contentFile = contentFile.toString();

    const allIndexes = findAllIndexString(
      contentFile,
      /--\[\[include\(['"](.*?)['"]\)\]\]/i
    );
    let indexCount = 0;

    contentFile = contentFile.replace(
      /--\[\[include\(['"](.*?)['"]\)\]\]/gi,
      function replacerWithPromise(match, grp) {
        let resultString = "";
        const CHAR_TO_REPLACE = " ";
        const packageNameStartIndex = pathname.lastIndexOf("/");
        const packageNameEndIndex = pathname.lastIndexOf(".");
        if (
          -1 < packageNameStartIndex &&
          packageNameStartIndex < packageNameEndIndex
        ) {
          grp = grp.replace(
            "{package-name}",
            pathname.substring(
              pathname.lastIndexOf("/"),
              pathname.lastIndexOf(".")
            )
          );
        }
        const filePath = String(grp).startsWith(".")
          ? dirname + grp.substring(1)
          : grp;

        const indent2fill = countIndentSpace(
          contentFile,
          allIndexes[indexCount++]
        );

        resultString = fs.readFileSync(filePath).toString();
        if (0 < indent2fill) {
          resultString = resultString
            .split("\n")
            .join("\n" + CHAR_TO_REPLACE.repeat(indent2fill));
        }
        return resultString;
      }
    );

    contentFile = `-- # compiled with plSqlBuilder on ${new Date().toString()}\n\n${contentFile}\n`;

    console.log("compile done for: ", pathname);
  } catch (e) {
    console.log("Error in buildPlSql: ", e);
  }
  return contentFile;
}

module.exports = build;
