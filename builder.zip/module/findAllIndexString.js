module.exports = (content, keyword) => {
  const result = [];
  let nextIndex = -1;
  let tempIndex = nextIndex;
  while (-1 !== content.search(keyword)) {
    tempIndex = content.search(keyword);
    nextIndex = nextIndex + 1 + tempIndex;

    result.push(nextIndex);
    content = content.substring(tempIndex + 1);
  }

  return result;
};
