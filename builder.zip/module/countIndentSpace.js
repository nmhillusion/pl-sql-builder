module.exports = (content, indexToFill = 0) => {
  const lastIndexOfCRLF = content.substring(0, indexToFill).lastIndexOf("\n");
  return indexToFill - lastIndexOfCRLF - 1;
};
