(_ => {
  console.log("bonus estimate");
})();
