const buildWebPage = require("./module/buildWebPage");
buildWebPage(
  "./webFiles/bonusEstimate",
  "C:\\Working\\Projects\\Java\\AIS\\aisclient\\src\\main\\webapp\\bonusEstimate.xhtml"
);
