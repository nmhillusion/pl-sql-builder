const fs = require("fs");

module.exports = {
  readFile(pathname) {
    return new Promise((res, rej) => {
      fs.readFile(pathname, (err, result) => {
        if (err) {
          rej(err);
        } else {
          res(result);
        }
      });
    });
  },
  readDir(dirname) {
    return new Promise((res, rej) => {
      fs.readdir(dirname, (err, files) => {
        if (err) {
          rej(err);
        } else {
          res(files);
        }
      });
    });
  },
  writeFile(pathname, data) {
    return new Promise((res, rej) => {
      fs.writeFile(pathname, data, (err, result) => {
        if (err) {
          rej(err);
        } else {
          res(result);
        }
      });
    });
  }
};
