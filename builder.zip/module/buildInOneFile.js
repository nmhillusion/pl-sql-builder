const fs = require("fs");

function build(outFile = "app.pck", ...inputFiles) {
  fs.writeFileSync(outFile, "");
  for (const iFile of inputFiles) {
    fs.appendFileSync(outFile, fs.readFileSync(iFile) + "\n\n");
  }
}

module.exports = build;
